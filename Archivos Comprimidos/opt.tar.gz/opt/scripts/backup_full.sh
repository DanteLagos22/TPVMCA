#!/bin/bash 

if [ "$1" = "help" ]; then
	echo "Uso: $0 origen destino"
	echo "El script realiza un backup del directorio ORIGEN hacia Destino"
	echo "El archivo generado tendra la fecha en formato YYYYMMDD"
	echo "Éjemplo: $0 /var/log /backup_dir"
	exit 0

elif [ $# -ne 2 ]; then
	echo "Error: Es requerido que se ingresen dos argumentos: ORIGEN y DESTINO"
	echo "Para ayuda: $0 help"
	exit 1
fi
if [ ! -d "$1" ]; then
	echo "Error: El directorio de origen ingresado '$1' no existe o no es accesible"
	exit 1
elif [ ! -d "$2" ]; then
	echo "Error: El directorio de destino ingresado '$2' no existe o no es accesible"
	exit 1
fi

FECHA=$(date +%Y%m%d)
BACKUP=$(basename "1")_bkp_$FECHA.tar.gz

tar -czf "$2/$BACKUP" -C "$1"

if [ -f "$2/$BACKUP"]; then
	echo "Backup creado correctamente en: $2/$BACKUP "
else 
	echo "Error: El Backup no se creo correctamente"
	exit 1
fi
